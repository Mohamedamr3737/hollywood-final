class AppAssets {
  static String icBody = "assets/icons/ic_body.png",
      icEar = "assets/icons/ic_ear.png",
      icEye = "assets/icons/ic_eye.png",
      icHeart = "assets/icons/ic_heart.png",
      icKidney = "assets/icons/ic_kidney.png",
      icLiver = "assets/icons/ic_liver.png",
      icLungs = "assets/icons/ic_lungs.png",
      icStomach = "assets/icons/ic_stomach.png",
      icTooth = "assets/icons/ic_tooth.png",
      imgLogin = "assets/images/img_login.jpg",
      imgSignup = "assets/images/img_signup.png",
      imgDoctor = "assets/images/doctor.jpg",
      imgWelcome = "assets/images/img_welcome.png";
}
