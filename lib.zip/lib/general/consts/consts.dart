export './colors.dart';
export './fonts.dart';
export './images.dart';
export './strings.dart';
export 'package:flutter/material.dart';
export 'package:velocity_x/velocity_x.dart';
export 'package:get/get.dart';

// Shared widgets should be placed in lib/general/widgets/
